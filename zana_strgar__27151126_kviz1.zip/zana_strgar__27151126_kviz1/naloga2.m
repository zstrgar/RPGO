%===== NALOGA 2 =====
b = 29/101;
p0 = (cos(b), -sin(b));
